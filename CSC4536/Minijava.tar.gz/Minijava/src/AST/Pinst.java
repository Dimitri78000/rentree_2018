package AST;
/** Pinst = "Instructions"; Abstract for RI* */
public abstract class Pinst extends PmethMember{
	Pinst(ASTNode ... fils){ super(fils);}
}
