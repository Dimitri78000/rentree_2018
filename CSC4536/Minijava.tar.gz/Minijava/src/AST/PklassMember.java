package AST;
/** PklassMember ; Abstract for ( Rmethod | Rfield ) */
public abstract class PklassMember extends ASTNode {
	PklassMember(ASTNode ... fils){ super(fils);}
}
