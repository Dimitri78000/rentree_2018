package AST;
/** Pexpr = "Expressions" ; Abstract for RE* */
public abstract class Pexpr extends ASTNode {
    Pexpr(ASTNode ... fils){ super(fils);}
}
