package AST;
/** PmethMember ; Abstract for Pinst | Rvar */
public abstract class PmethMember extends ASTNode {
	PmethMember(ASTNode ... fils){ super(fils);}
}
