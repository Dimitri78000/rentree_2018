class Test103 {
	public static void main(String[] args) {
		System.out.println(new Test2().Start(9));
	}
}
class Test2 {
	public int Start(int y) {
		return y;
	}
}