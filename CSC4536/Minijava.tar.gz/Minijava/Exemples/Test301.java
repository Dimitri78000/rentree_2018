
/**
 * Stress Test lexicale et syntaxique (Valid)
 */ 
class Test301 {

	// This should be ignored
    /* So should this /* 
    and this still */

	public static void main(String[] args){
			System.out.println(new Bar() . /* comment */  //
					Compute());
		}
	}   

class Bar {
	public  int Compute() {
		int _α_ ;
        if (__meep00) {
            a = (138 + jiosfd * meep - bar < a)[33];
        } else {
            while (c)
                a = -5 ;
        }
        if (mm) { /* empty block */ }
        else b=a; /* mono instruction block */
        
        int[] a;
        boolean b;
        int c;
        return b*this.length + ! true && 5 ;
    }
}

class Foo extends Meep {
    public int[] yarrr() {
        Meep a;
        a = new Meep();
        a[2] = (aa + bb).yarrr();
        System . out .   println(5);
        System  .  out /* comment */ . println(38);
        System 
        .  out //comment
        . println(38);
     return false ;
    }
}

