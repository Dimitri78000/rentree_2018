class Test303{
	public static void main(String[] args){
		System.out.println.(new Fac().ComputeFac());  //Statement Error: Line 3
	}
}

class Fac{
	public int ErrorTime (int){   //Formal Parameter Error: Line 8
	}
    public int ComputeFac (int num){
	int y;
	int  ;         //Variable Declaration Error: line 12
	if (num < 1)
	    num_aux = 1 ;
	else 
	    num_aux = num * (this.ComputeFac num-1)) ;  //Actual Parameter Error: line 16
	return num_aux ;
    }
}

Foo{  //Class Body Error: Line 21
	public int bar(){
		return 0;
	}
}

class Error{
	public  Foo (int num){   //Method Body Error: Line 28
	return 1 ;
    }
}