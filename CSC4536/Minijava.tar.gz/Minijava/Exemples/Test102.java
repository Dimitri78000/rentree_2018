class Test102 {
	public static void main(String[] args) {
		System.out.println(5+4);
	}
}